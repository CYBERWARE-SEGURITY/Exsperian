
  ________   __ _____ _____  ______ _____  _____          _   _                
 |  ____\ \ / // ____|  __ \|  ____|  __ \|_   _|   /\   | \ | |               
 | |__   \ V /| (___ | |__) | |__  | |__) | | |    /  \  |  \| |  _____  _____ 
 |  __|   > <  \___ \|  ___/|  __| |  _  /  | |   / /\ \ | . ` | / _ \ \/ / _ \
 | |____ / . \ ____) | |    | |____| | \ \ _| |_ / ____ \| |\  ||  __/>  <  __/
 |______/_/ \_\_____/|_|    |______|_|  \_\_____/_/    \_\_| \_(_)___/_/\_\___|
                                                                               
                                                                               
------------------------------------------------
✧ INFORMATION ✧
Developer: CYBERWARE
Coded in: C# & ASM
Version: 1.0
Category: Trojan-Gdi.Win32
Compatible Platforms: Windows 11\10\8.1 (in 8.1 Need NET Framework 4.0 to 4.8)
Modifies MBR? YES
------------------------------------------------

⊗ PHOTOSENSITIVE SEIZURE WARNING (example: EPILEPSY) ⊗
Includes Specific Graphic Effects? YES
Contains Loud or Intense Audio? YES

☢ ATTENTION ☢
I, CYBERWARE, am not responsible for any damages or losses that may occur.

☞ RECOMMENDATION ☞
If you want to test for studies or ideas, I strongly recommend using Virtual Machines such as (VMware or VirtualBox).

------------------------------------------------

⇩ NETWORKS ⇩

♤ YOUTUBE: [CYBERWARE] (https://www.youtube.com/@CYBERWARE)
❀ GITHUB: [CYBERWARE-SECURITY] (https://github.com/CYBERWARE-SEGURITY)
✯ DISCORD: t3nx1l
☁ MY SITE: [CyberWareCursos] (https://linkfly.to/CyberWareCursos)
